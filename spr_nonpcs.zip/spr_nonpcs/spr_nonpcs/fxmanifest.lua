fx_version 'cerulean'
game 'gta5'

author 'SPR DEV'
description 'ESX No NPC Resource'
version '1.0.0'

lua54 'yes'

client_script 'no_npc.lua'
