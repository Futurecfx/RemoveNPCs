Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)

        -- Remove nearby NPCs
        RemoveAllNearbyNPCs()
    end
end)

-- Function to remove nearby NPCs
function RemoveAllNearbyNPCs()
    local pedDensity = GetPedDensityMultiplier()
    SetPedDensityMultiplierThisFrame(0.0) -- Set ped density multiplier to 0 to prevent NPCs from spawning
    SetScenarioPedDensityMultiplierThisFrame(0.0, 0.0) -- Set scenario ped density multiplier to 0
    SetVehicleDensityMultiplierThisFrame(0.0) -- Set vehicle density multiplier to 0 to prevent vehicle-related NPCs from spawning
    SetRandomVehicleDensityMultiplierThisFrame(0.0) -- Set random vehicle density multiplier to 0
    SetParkedVehicleDensityMultiplierThisFrame(0.0) -- Set parked vehicle density multiplier to 0
    SetCreateRandomCops(false) -- Disable random cop spawns

    -- Clear all NPC vehicles
    local vehicles = GetGamePool('CVehicle')
    for _, vehicle in ipairs(vehicles) do
        local model = GetEntityModel(vehicle)
        if IsThisModelABoat(model) or IsThisModelACar(model) or IsThisModelABike(model) or IsThisModelAQuadbike(model) or IsThisModelAHeli(model) or IsThisModelAPlane(model) then
            SetEntityAsMissionEntity(vehicle, true, true)
            DeleteVehicle(vehicle)
        end
    end

    -- Clear all NPC peds
    local peds = GetGamePool('CPed')
    for _, ped in ipairs(peds) do
        if IsPedHuman(ped) and not IsPedAPlayer(ped) then
            SetEntityAsMissionEntity(ped, true, true)
            DeletePed(ped)
        end
    end

    SetPedDensityMultiplierThisFrame(pedDensity) -- Restore original ped density multiplier
end
